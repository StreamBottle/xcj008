export * from './common_prompt.service';
export * from './common_prompt.component';