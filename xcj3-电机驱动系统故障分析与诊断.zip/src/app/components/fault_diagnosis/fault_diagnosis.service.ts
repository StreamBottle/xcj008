import { Injectable } from '@angular/core';

@Injectable()
export class FaultDiagnosisService {
    // public isSubmit = false; // 是否提交
    // public isShowAnswer = false; // 是否显示正确答案

    skill01 = {
        isSubmit: false, // 是否提交
        isShowAnswer: false // 是否显示正确答案
    }
    skill02 = {
        isSubmit: false, // 是否提交
        isShowAnswer: false // 是否显示正确答案
    }
    skill03 = {
        isSubmit: false, // 是否提交
        isShowAnswer: false // 是否显示正确答案
    }
    skill04 = {
        isSubmit: false, // 是否提交
        isShowAnswer: false // 是否显示正确答案
    }
    skill05 = {
        isSubmit: false, // 是否提交
        isShowAnswer: false // 是否显示正确答案
    }
    skill06 = {
        isSubmit: false, // 是否提交
        isShowAnswer: false // 是否显示正确答案
    }
    skill07 = {
        isSubmit: false, // 是否提交
        isShowAnswer: false // 是否显示正确答案
    }
    skill08 = {
        isSubmit: false, // 是否提交
        isShowAnswer: false // 是否显示正确答案
    }
    exam01 = {
        isSubmit: false, // 是否提交
        isShowAnswer: false // 是否显示正确答案
    }

    constructor() { }
}