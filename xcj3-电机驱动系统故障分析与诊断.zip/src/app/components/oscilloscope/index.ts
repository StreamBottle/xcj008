export * from './oscilloscope.component';
export * from './oscilloscope.service';