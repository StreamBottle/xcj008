import { Injectable }    from '@angular/core';
import { Resource } from '../../interface/resources';
@Injectable()
export class PopupService {
    popupsData:any;
    
}