export * from './promp.component';
