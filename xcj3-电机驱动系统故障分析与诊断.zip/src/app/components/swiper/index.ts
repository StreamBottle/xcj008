export * from './swiper.component';
