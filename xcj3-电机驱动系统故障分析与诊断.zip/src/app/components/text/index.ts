export * from './text.component';
