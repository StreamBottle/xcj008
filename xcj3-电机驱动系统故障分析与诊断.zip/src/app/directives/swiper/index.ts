export * from './swiper.directive';

