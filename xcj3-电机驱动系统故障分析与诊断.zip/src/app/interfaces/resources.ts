export class Resource {
    index: string;
    infoText: Object;
    audioSrc: string[]
}

