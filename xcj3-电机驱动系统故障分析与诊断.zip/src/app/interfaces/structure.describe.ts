export class  StructureDescribe{
   index:string;
   infoText:Object;
}
