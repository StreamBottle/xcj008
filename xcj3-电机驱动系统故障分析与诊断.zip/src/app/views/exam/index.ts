export * from './exam.component';
