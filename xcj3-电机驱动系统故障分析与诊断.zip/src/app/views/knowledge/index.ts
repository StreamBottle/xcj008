export * from './knowledge.component';
