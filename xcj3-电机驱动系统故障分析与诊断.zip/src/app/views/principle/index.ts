export * from './principle.component';
